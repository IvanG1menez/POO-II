### Diagrama de Clases - Patrón Decorator

La interfaz `Pizza` define los métodos necesarios para obtener la descripción y el precio de una pizza. La clase `PizzaBasica` implementa esta interfaz y representa una pizza simple sin ingredientes adicionales. Para los complementos, utilizamos el patrón Decorator mediante la clase abstracta `PizzaDecorator`, que contiene una referencia a un objeto `Pizza`. Cada decorador específico (como `QuesoExtra`, `Jamon`, y `Champinones`) extiende `PizzaDecorator`, permitiendo añadir funcionalidad extra y precio adicional de manera dinámica sin modificar la estructura original de `Pizza`.

### Ejemplo de Implementación en `App`

En este ejemplo, comenzamos con una `PizzaBasica` y agregamos decoradores para personalizarla con `QuesoExtra`, `Jamon`, y `Champinones`. Cada decorador añade un ingrediente y su costo asociado. La implementación del patrón Decorator permite que la `Pizza` se modifique dinámicamente sin alterar la clase base. El resultado es una pizza personalizada, con una descripción completa de sus ingredientes y el precio final calculado en base a los complementos añadidos.
