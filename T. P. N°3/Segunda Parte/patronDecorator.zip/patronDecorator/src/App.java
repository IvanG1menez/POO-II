import edu.unam.modelo.*;

public class App {
    public static void main(String[] args) {
        // Creamos una pizza básica
        Pizza pizza = new PizzaBasica();
        
        // Añadimos queso extra a la pizza
        pizza = new QuesoExtra(pizza);
        
        // Añadimos jamón a la pizza
        pizza = new Jamon(pizza);
        
        // Añadimos champiñones a la pizza
        pizza = new Champinones(pizza);

        // Imprimimos la descripción y el precio final de la pizza
        System.out.println("Descripción: " + pizza.obtenerDescripcion());
        System.out.println("Precio total: $" + pizza.obtenerPrecio());
    }
}
