package edu.unam.modelo;

/**
 * Decorador que añade champiñones a la pizza.
 */
public class Champinones extends PizzaDecorator {

    public Champinones(Pizza pizza) {
        super(pizza);
    }

    @Override
    public String obtenerDescripcion() {
        return pizza.obtenerDescripcion() + ", Champiñones";
    }

    @Override
    public double obtenerPrecio() {
        return pizza.obtenerPrecio() + 1.75; // Precio adicional por champiñones
    }
}

