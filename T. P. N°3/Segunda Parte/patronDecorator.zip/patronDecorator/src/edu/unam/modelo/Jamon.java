package edu.unam.modelo;

/**
 * Decorador que añade jamón a la pizza.
 */
public class Jamon extends PizzaDecorator {

    public Jamon(Pizza pizza) {
        super(pizza);
    }

    @Override
    public String obtenerDescripcion() {
        return pizza.obtenerDescripcion() + ", Jamón";
    }

    @Override
    public double obtenerPrecio() {
        return pizza.obtenerPrecio() + 2.00; // Precio adicional por jamón
    }
}

