package edu.unam.modelo;

/**
 * Representa una pizza básica sin ingredientes adicionales.
 */
public class PizzaBasica implements Pizza {

    @Override
    public String obtenerDescripcion() {
        return "Pizza básica";
    }

    @Override
    public double obtenerPrecio() {
        return 5.00; // Precio base de la pizza
    }
}

