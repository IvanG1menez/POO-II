package edu.unam.modelo;

/**
 * Decorador abstracto que permite añadir ingredientes adicionales a la pizza.
 */
public abstract class PizzaDecorator implements Pizza {
    protected Pizza pizza;

    /**
     * Constructor del decorador que recibe una pizza.
     * @param pizza la pizza base a decorar.
     */
    public PizzaDecorator(Pizza pizza) {
        this.pizza = pizza;
    }

    @Override
    public String obtenerDescripcion() {
        return pizza.obtenerDescripcion();
    }

    @Override
    public double obtenerPrecio() {
        return pizza.obtenerPrecio();
    }
}
