package edu.unam.modelo;

/**
 * Decorador que añade queso extra a la pizza.
 */
public class QuesoExtra extends PizzaDecorator {

    public QuesoExtra(Pizza pizza) {
        super(pizza);
    }

    @Override
    public String obtenerDescripcion() {
        return pizza.obtenerDescripcion() + ", Queso Extra";
    }

    @Override
    public double obtenerPrecio() {
        return pizza.obtenerPrecio() + 1.50; // Precio adicional por queso extra
    }
}

