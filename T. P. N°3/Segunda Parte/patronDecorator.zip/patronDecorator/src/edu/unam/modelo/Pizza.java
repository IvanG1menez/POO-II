package edu.unam.modelo;

/**
 * Interfaz que define los métodos básicos de una pizza.
 */
public interface Pizza {
    /**
     * Devuelve la descripción de la pizza.
     * @return la descripción de la pizza.
     */
    String obtenerDescripcion();

    /**
     * Devuelve el precio de la pizza.
     * @return el precio de la pizza.
     */
    double obtenerPrecio();
}

